import 'package:flutter/material.dart';
import '../data/property.dart';
import 'description.dart';

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with TickerProviderStateMixin {
  final List<Property> properties = [
    Property(name: 'Luxury Villa', image: 'assets/image.png', price: 500000, description: 'A stunning villa with a sea view.'),
    Property(name: 'Modern Apartment', image: 'assets/image_1.png', price: 200000, description: 'Stylish apartment in the city center.'
        'A suitable enviroment for your family at a low budget cost'),
    Property(name: 'Cozy Cottage', image: 'assets/image_2.png', price: 150000, description: 'A warm and cozy cottage in the countryside.'),
    Property(name: 'Penthouse Suite', image: 'assets/image_3.png', price: 750000, description: 'Luxurious penthouse with a city skyline view.'),
    Property(name: 'Beachfront Bungalow', image: 'assets/image_4.png', price: 600000, description: 'Bungalow located right on the beach.'),
    Property(name: 'Country Farmhouse', image: 'assets/image_5.png', price: 350000, description: 'Spacious farmhouse with acres of land.'),
  ];

  late final List<AnimationController> _controllers;
  late final List<Animation<double>> _animations;

  @override
  void initState() {
    super.initState();
    _controllers = List.generate(
      properties.length,
          (index) => AnimationController(
        duration: const Duration(milliseconds: 1000),
        vsync: this,
      ),
    );
    _animations = _controllers
        .map((controller) => CurvedAnimation(parent: controller, curve: Curves.easeIn))
        .toList();

    for (int i = 0; i < _controllers.length; i++) {
      Future.delayed(Duration(milliseconds: i * 300), () {
        _controllers[i].forward();
      });
    }
  }

  @override
  void dispose() {
    for (final controller in _controllers) {
      controller.dispose();
    }
    super.dispose();
  }

  Row _buildJournalWeather(String temperature, String condition, String address) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Icon(
              Icons.wb_sunny,
              color: Colors.orange,
            ),
          ],
        ),
        SizedBox(width: 16.0,),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Text(
                  '$temperature $condition',
                  style: TextStyle(color: Colors.deepOrange),
                ),
              ],
            ),
            Row(
              children: <Widget>[
                Text(
                  '$address',
                  style: TextStyle(color: Colors.grey),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Altaf Properties'),
        backgroundColor: Colors.teal[300],
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {},
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {},
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                for (int index = 0; index < properties.length; index++)
                  FadeTransition(
                    opacity: _animations[index],
                    child: Dismissible(
                      key: Key(properties[index].name),
                      direction: DismissDirection.endToStart, // Dismiss from right to left
                      onDismissed: (direction) {
                        // You can handle the item removal here, for example:
                        setState(() {
                          properties.removeAt(index); // Remove the property from the list
                        });

                        // Show a snack bar after the item is dismissed
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text("${properties[index].name} has been removed"),
                          ),
                        );
                      },
                      background: Container(
                        color: Colors.red, // Background color when swiping
                        alignment: Alignment.centerRight,
                        child: const Icon(
                          Icons.delete,
                          color: Colors.white,
                          size: 40,
                        ),
                      ),
                      child: Card(
                        elevation: 5,
                        margin: const EdgeInsets.symmetric(vertical: 10),
                        child: ListTile(
                          contentPadding: const EdgeInsets.all(16.0),
                          leading: ClipOval(
                            child: Image.asset(properties[index].image, width: 50, height: 50, fit: BoxFit.cover),
                          ),
                          title: Text(
                            properties[index].name,
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Price: OMR ${properties[index].price}',
                                style: const TextStyle(fontSize: 16, color: Colors.grey),
                              ),
                              const SizedBox(height: 8),
                              Divider(color: Colors.grey),
                              const SizedBox(height: 8),
                              Chip(
                                label: Text(properties[index].description),
                                backgroundColor: Colors.blue[100],
                              ),
                              // Add the weather details below each property
                              _buildJournalWeather(
                                '49º', // Temperature for this property
                                'Clear', // Weather condition
                                'Muscat, Oman', // Address
                              ),
                            ],
                          ),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Description(property: properties[index]),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
