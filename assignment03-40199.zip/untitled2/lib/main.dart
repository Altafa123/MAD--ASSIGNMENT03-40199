import 'package:flutter/material.dart';
import 'pages/home.dart';

void main() {
  runApp(
    const MaterialApp(
      title: 'Altaf Properties',
      home: Home(),
      debugShowCheckedModeBanner: false,
    ),
  );
}
